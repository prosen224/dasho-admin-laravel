<!DOCTYPE html>
<html lang="en">
  
<!-- Mirrored from themes.rokaux.com/unishop/v3.1/template-1/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Feb 2019 17:24:04 GMT -->
<head>
    <meta charset="utf-8">
    <title>ABPAFC - Association Of Bangladeshi Professional in Accounting And Finance, Toranto, Canada</title>
    <!-- SEO Meta Tags-->
    <meta name="description" content="Cheapers - Cheapers">
    <!-- Mobile Specific Meta Tag-->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <!-- Favicon and Apple Icons-->
    <link rel="icon" type="image/x-icon" href="favicon.ico">
    <link rel="icon" type="image/png" href="favicon.png">
    <link rel="apple-touch-icon" href="touch-icon-iphone.png">
    <link rel="apple-touch-icon" sizes="152x152" href="<?php echo base_url(); ?>website_assets/touch-icon-ipad.png">
    <link rel="apple-touch-icon" sizes="180x180" href="<?php echo base_url(); ?>website_assets/touch-icon-iphone-retina.png">
    <link rel="apple-touch-icon" sizes="167x167" href="<?php echo base_url(); ?>website_assets/touch-icon-ipad-retina.png">
    <!-- Vendor Styles including: Bootstrap, Font Icons, Plugins, etc.-->
    <link rel="stylesheet" media="screen" href="<?php echo base_url(); ?>website_assets/css/vendor.min.css">
    <!-- Main Template Styles-->
    <link id="mainStyles" rel="stylesheet" media="screen" href="<?php echo base_url(); ?>website_assets/css/styles.min.css">
    <!-- Customizer Styles-->
    <link rel="stylesheet" media="screen" href="<?php echo base_url(); ?>website_assets/customizer/customizer.min.css">
    <!-- Google Tag Manager-->
    <script>
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
      new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
      j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
      '../../../../www.googletagmanager.com/gtm5445.html?id='+i+dl;f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','GTM-T4DJFPZ');
      
    </script>
    <!-- Modernizr-->
    <script src="<?php echo base_url(); ?>website_assets/js/modernizr.min.js"></script>

        <style>
    .product-card:hover {
    box-shadow: 2px 2px 8px #bbb !important;
    transition: 0.5s;

}
.form-control:not(textarea) {
    height: 39px;
}

.hero-slider {
    max-height: 520px !important;
    
}
.site-logo
{
     color: green !important;
    font-size: 22px;
    font-weight: 410;
    letter-spacing: .05em;
    line-height: 70px;
    text-transform: uppercase;
    text-shadow: 1px 1px 3px green !important;
     padding: 12px 0 12px 25px;
     padding-top: 8px;
}



/*@media (max-width: 1100px).hero-slider {
     min-height: 0px !important; 
}*/

.topbar {
    display: table;
    position: relative;
    width: 100%;
    height: 40px;
    padding: 0 30px;
    border-bottom: 1px solid #e1e7ec;
    background-color: #22E5A7;
    

/*background-color: #C72A2F;
*/
    
    z-index: 9010;
    color:white !important;
}

.topbar-column a
{
  color:white;
}

 .icon-mail
 {
  color:white;
 }
.icon-bell
 {
  color:white;
 }

 .site-menu>ul>li a{

    text-shadow: 1px 1px 2px #979797;


}



.offcanvas-toggle {
    border-right: 0px solid #e1e7ec;
   
}


.product-card 
    {
        display: block;
        position: relative;
        width: 100%;
        padding: 18px;
        border: 1px solid #e1e7ec;
        border-radius: 7px;
        background-color: #fff;
        box-shadow: 2px 2px 8px #bbb !important;
        transition: 0.5s;
    }

    .product-card:hover {
    box-shadow: 0px 0px 0px #bbb !important;
    transition: 0.5s;
}

    .mb-30 
    {
        margin-bottom: 30px !important;
    }
    .product-card .product-buttons {
        padding: 12px 0 8px;
        text-align: center;
    }
    .product-card .product-buttons>.btn {
    margin: 0 4px;
}
.product-card .product-buttons>.btn {
    margin: 0 4px;
}
.btn:hover {
    border-radius: 10px !important;
    box-shadow: 0px 0px 0px graytext !important;
}
.btn-outline-primary:hover {
    background-color: #0da9ef;
    color: #fff;
}
.btn:hover {
    color: #606975;
}
.btn:hover, .btn:focus .btn:active, .btn.active {
    outline: none;
    background-image: none;
    text-decoration: none;
    box-shadow: none;
}
a:hover {
    color: #0da9ef;
    text-decoration: none;
}
.btn {
    border-radius: 10px !important;
    box-shadow: 1px 4px 1px graytext !important;
}
.btn-outline-primary {
    border-color: #0da9ef;
    background-color: transparent;
    color: #0da9ef;
}
.btn-sm {
    height: 36px;
    padding: 0 18px;
    border-radius: 18px;
    font-size: 12px;
    line-height: 34px;
}
.btn {
    display: inline-block;
    position: relative;
    height: 44px;
    margin-top: 8px;
    margin-right: 12px;
    margin-bottom: 8px;
    padding: 0 22px;
    -webkit-transform: translateZ(0);
    transform: translateZ(0);
    transition: all .4s;
    border: 1px solid transparent;
    border-radius: 22px;
    background-color: transparent;
    background-image: none;
    color: #606975;
    font-family: "Maven Pro",Helvetica,Arial,sans-serif;
    font-size: 14px;
    font-style: normal;
    font-weight: 500;
    letter-spacing: .07em;
    line-height: 42px;
    white-space: nowrap;
    cursor: pointer;
    vertical-align: middle;
    text-transform: uppercase;
    text-decoration: none;
    text-align: center;
    -ms-touch-action: manipulation;
    touch-action: manipulation;
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
}

.site-logo {
    width: 90px;
    padding: 12px 0 12px 25px;
    text-decoration: none;
}


/*Newly added*/

.site-menu>ul>li a {
    text-shadow: 1px 1px 2px #979797;
}
.site-menu>ul>li>a {
    display: table;
    height: 100%;
    min-height: 100%;
    border-top: 1px solid transparent;
    /* letter-spacing: .05em; */
    /* text-transform: uppercase; */
}
.site-menu ul>li>a {
    padding: 0 15px;
    transition: color .3s;
    color: black;
    font-size: 15px;
/*    font-weight: 550;
*/    text-decoration: none;

    letter-spacing: .05em;
    text-transform: none !important;
       font-family: "Cinzel Decorative",cursive;
    font-size: 1.15em;
    font-weight: 500;
    font-style: normal;
    text-decoration: none;
    text-transform: none;
    letter-spacing: normal;
    
}

.site-menu>ul>li>a {
    display: table;
    height: 100%;
    min-height: 100%;
    border-top: 1px solid transparent;
    letter-spacing: .05em;
    text-transform: none !important;
       font-family: "Cinzel Decorative",cursive;
    font-size: 0.96em;
    font-weight: 550;
    font-style: normal;
    text-decoration: none;
    text-transform: uppercase !important;
    letter-spacing: normal;

}

.topbar {
    display: table;
    position: relative;
    width: 100%;
    height: 30px;
    padding: 0 30px;
    border-bottom: 1px solid #e1e7ec;
    background-color: #22E5A7;
    

/*background-color: #C72A2F;
*/
    
    z-index: 9010;
    color:white !important;
}

.navbar {

    min-height: 60px;

}
.site-logo {
    width: 90px;
    padding: 0px 0 0px 30px;
    text-decoration: none;
}

.welcome_img {
    max-width: 100%;
    height: 250px !important;
    vertical-align: middle;
}
a{
  text-decoration: none;
}

.widget-title {
    border-bottom: 0px solid #e1e7ec;
}

    </style>
  </head>
  
  <body>
    <!-- Off-Canvas Category Menu-->
    <!-- <div class="offcanvas-container" id="shop-categories">
      <div class="offcanvas-header">
        <h3 class="offcanvas-title">Shop Categories</h3>
      </div>
      <nav class="offcanvas-menu">
        <ul class="menu">
          <?php foreach($get_all_category as $category_all){?>
          <li class="has-children"><span><a href="<?php echo base_url();?>index.php/website/get_product_by_category/<?php echo $category_all->id;?>"><?php echo $category_all->name?></a><span class="sub-menu-toggle"></span></span>
            <ul class="offcanvas-submenu">
              <?php if(isset($formatted_sub_cat[$category_all->id])){?>
              <?php foreach($formatted_sub_cat[$category_all->id] as $row_formatted_sub_cat){?>
              <li><a href="<?php echo base_url();?>index.php/website/get_product_by_subcategory/<?php echo $row_formatted_sub_cat['id']?>"><?php echo $row_formatted_sub_cat['name'];?></a></li>
              <?php } ?>
              <?php } ?>
              
            </ul>
          </li>
          <?php } ?>
        </ul>
      </nav>
    </div> -->
    <!-- Off-Canvas Mobile Menu-->
    <div class="offcanvas-container" id="mobile-menu">
      <nav class="offcanvas-menu">
        <ul class="menu">
          <li class="active"><span><a href="<?php echo base_url('/index.php/website/index');?>"><span>Home</span></a><span class="sub-menu-toggle"></span></span>
            
          </li>
          <li class="has-children"><span><a href="<?php echo base_url('/index.php/website/vision_and_mission');?>"><span>About Us</span></a><span class="sub-menu-toggle"></span></span>
            <ul class="offcanvas-submenu">
             
              <li class=""><a href="<?php echo base_url('/index.php/website/objectives');?>"><span>Objectives</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/vision_and_mission');?>"><span>Our Vision And Mission</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/diectors_profile');?>"><span>Directors Profile</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/photo_gallery');?>"><span>Photo Gallery</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/video_gallery');?>"><span>Video Gallery</span></a>
              </li>
              <li>
                  <a href="<?php echo base_url('/index.php/website/budget_for_present_year');?>">Budget For Present Year</a>
              </li>

              <li>
                  <a href="<?php echo base_url('/index.php/website/financial_for_past_year');?>">Financial For Past Years</a>
              </li>
            </ul>
          </li>
          

          <li class="has-children"><span><a href="#"><span>Committee</span></a><span class="sub-menu-toggle"></span></span>
            <ul class="offcanvas-submenu">
             
             <li class=""><a href="<?php echo base_url('/index.php/website/present_committee');?>"><span>Present</span></a>
              </li>
              <!-- <li class=""><a href="<?php echo base_url('/index.php/website/sub_committee');?>"><span>Sub-Committee</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/advisory');?>"><span>Advisory</span></a>
              </li> -->
              <li class=""><a href="<?php echo base_url('/index.php/website/past');?>"><span>Past</span></a>
              </li>
               
               <li class=""><a href="<?php echo base_url('/index.php/website/members');?>"><span>Members</span></a>                
              </li>

              <li>
                  <a href="<?php echo base_url('/index.php/website/member_view');?>">Download Application Form</a>
              </li>

              <li>
                  <a href="<?php echo base_url('/index.php/website/benefits_to_be_member');?>">Benefits To Become A Member</a>
              </li>


            </ul>
          </li>


          <li class="has-children"><span><a href="#"><span>Circular</span></a><span class="sub-menu-toggle"></span></span>
            <ul class="offcanvas-submenu">
             
              <li class=""><a href="<?php echo base_url('/index.php/website/board_meeting');?>"><span>Board Meeting</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/yearly_subscription');?>"><span>Notice Of Payment Of Yearly Subscriptions</span></a>
              </li>
              <li>
                  <a href="<?php echo base_url('/index.php/website/upcoming_events_past');?>">Past</a>
              </li>

              <li>
                  <a href="<?php echo base_url('/index.php/website/upcoming_events_picnic');?>">Future - Picnic</a>
              </li>

              <li>
                  <a href="<?php echo base_url('/index.php/website/upcoming_events_seminar');?>">Future - Seminar</a>
              </li>
                    
            </ul>
          </li>
          <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/new_comer/');?>"><span>Newcomer</span></a>
          </li>
          <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/contact_us_view/');?>"><span>Contact Us</span></a>
          </li>
           <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/registration_view/');?>"><span>Registration</span></a>
          </li>
           <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/member_view/');?>"><span>Become A Member</span></a>
          </li>

        </ul>
      </nav>
    </div>
    <div class="topbar">
      <marquee style="color:black;">We are here to help everyone in need General Member: Any Bangladeshi Accounting or Finance Professional with the following qualifications is eligible to become a ‘General’ member</marquee>
     <!--  <div class="topbar-column"><a class="hidden-md-down" href="mailto:support@abpafc.com"><i class="icon-mail"></i><span style="color:white;">&nbsp; support@abpafc.com</span></a><a class="hidden-md-down" href="tel:+880 199 2969 618"><i class="icon-bell"></i><span style="color:white;">&nbsp; +880 111 222 333</span></a><a class="social-button sb-facebook shape-none sb-dark" href="#" target="_blank"><i class="socicon-facebook"></i></a><a class="social-button sb-twitter shape-none sb-dark" href="#" target="_blank"><i class="socicon-twitter"></i></a><a class="social-button sb-instagram shape-none sb-dark" href="#" target="_blank"><i class="socicon-instagram"></i></a><a class="social-button sb-pinterest shape-none sb-dark" href="#" target="_blank"><i class="socicon-pinterest"></i></a>
      </div>
      <div class="topbar-column">
        <p><a href="#"><span style="color:white;">Sign up</span></a><span style="color:white;">/</span><a href="#"><span style="color:white;">Login</span></a></P>
      </div> -->
    </div>
    <!-- Navbar-->
    <!-- Remove "navbar-sticky" class to make navigation bar scrollable with the page.-->
    <header class="navbar navbar-sticky">
      <!-- Search-->
      <form class="site-search" method="get">
        <input type="text" name="site_search" placeholder="Type to search...">
        <div class="search-tools"><span class="clear-search">Clear</span><span class="close-search"><i class="icon-cross"></i></span></div>
      </form>
      <div class="site-branding">
        <div class="inner">
          <!-- Off-Canvas Toggle (#shop-categories)-->

          <!-- <a class="offcanvas-toggle cats-toggle" href="#shop-categories" data-toggle="offcanvas"></a> -->


          <!-- Off-Canvas Toggle (#mobile-menu)--><a class="offcanvas-toggle menu-toggle" href="#mobile-menu" data-toggle="offcanvas"></a>
          <!-- Site Logo-->
          <a class="site-logo" href="<?php echo base_url('/index.php/website/');?>"><img src="<?php echo base_url(); ?>images/logoabpafc.png" alt=""></a>
        </div>
      </div>
      <!-- Main Navigation-->
      <nav class="site-menu">
        <ul>
          <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/index');?>"><span>Home</span></a>
          </li>
          <li><a href="<?php echo base_url('/index.php/website/vision_and_mission');?>"><span>About Us</span></a>
            <ul class="sub-menu">            
              <li class=""><a href="<?php echo base_url('/index.php/website/objectives');?>"><span>Objectives</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/vision_and_mission');?>"><span>Our Vision And Mission</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/diectors_profile');?>"><span>Directors Profile</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/photo_gallery');?>"><span>Photo Gallery</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/video_gallery');?>"><span>Video Gallery</span></a>
              </li>
              <li class="has-children"><a href=""><span>Financial</span></a>
                
                <ul class="sub-menu">
                    
                    <li>
                        <a href="<?php echo base_url('/index.php/website/budget_for_present_year');?>">Budget For Present Year</a>
                    </li>

                    <li>
                        <a href="<?php echo base_url('/index.php/website/financial_for_past_year');?>">Financial For Past Years</a>
                    </li>
                </ul>
                
              </li>

            </ul>
          </li>

          <li><a href="#"><span>Committee</span></a>
            <ul class="sub-menu">            
              <li class=""><a href="<?php echo base_url('/index.php/website/present_committee');?>"><span>Present</span></a>
              </li>
            <!--   <li class=""><a href="<?php echo base_url('/index.php/website/sub_committee');?>"><span>Sub-Committee</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/advisory');?>"><span>Advisory</span></a>
              </li> -->
              <li class=""><a href="<?php echo base_url('/index.php/website/past');?>"><span>Past</span></a>
              </li>
              
              <li class=""><a href="<?php echo base_url('/index.php/website/members');?>"><span>Members</span></a>                
              </li>

              <li class="has-children"><a href=""><span>Become A Member</span></a>
                
                <ul class="sub-menu">
                    
                    <li>
                        <a href="<?php echo base_url('/index.php/website/member_view');?>">Download Application Form</a>
                    </li>

                    <li>
                        <a href="<?php echo base_url('/index.php/website/benefits_to_be_member');?>">Benefits To Become A Member</a>
                    </li>
                </ul>
                
              </li>

            </ul>
          </li>

          <li><a href="#"><span>Circular</span></a>
            <ul class="sub-menu">            
              <li class=""><a href="<?php echo base_url('/index.php/website/board_meeting');?>"><span>Board Meeting</span></a>
              </li>
              <li class=""><a href="<?php echo base_url('/index.php/website/yearly_subscription');?>"><span>Notice Of Payment Of Yearly Subscriptions</span></a>
              </li>
              <li class="has-children"><a href="#"><span>Upcoming Events</span></a>
                
                <ul class="sub-menu">
                    
                    <li>
                        <a href="<?php echo base_url('/index.php/website/upcoming_events_past');?>">Past</a>
                    </li>

                    <li>
                        <a href="<?php echo base_url('/index.php/website/upcoming_events_picnic');?>">Future - Picnic</a>
                    </li>

                    <li>
                        <a href="<?php echo base_url('/index.php/website/upcoming_events_seminar');?>">Future - Seminar</a>
                    </li>
                </ul>
                
              </li>
            </ul>
          </li>

          <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/new_comer/');?>"><span>Newcomer</span></a>
          </li>
          <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/contact_us_view/');?>"><span>Contact Us</span></a>
          </li>
           <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/registration_view/');?>"><span>Registration</span></a>
          </li>
           <li class="has-megamenu"><a href="<?php echo base_url('/index.php/website/member_view/');?>"><span>Become A Member</span></a>
          </li>

        </ul>
      </nav>
  
    </header>
    <!-- Off-Canvas Wrapper-->


     


    <div class="offcanvas-wrapper">
        
      <div class="page-title" style="background-color: rgb(92,25,22) !important;">
        <div class="container">
          <div class="column">
            <div class="row">
            
            <div class="offset-md-4 col-md-4">
              <h3 style="text-shadow: 2px 2px 4px #000000;color: #61d800;font-weight:bold;">
                <p class="text-center" >Our Vision And Mission</p>
              </h3>
            </div>

           

          </div>
          </div>
          
        </div>
      </div>
      
      <section class="container" style="box-shadow: 0px 0px 8px #bbb;margin-top:-10px !important;margin-bottom:100px;border: 1px solid #e1e7ec;border-radius:8px;padding-top:20px;padding-bottom:10px;">

</h3>
         
        <div class="row">
          <div class="col-md-1">
          </div>
          <div class="col-md-5">
            <div class="#">
              
              <div class="row">

                <div class="col-md-12">
                  <div class="teacher-info">


                    <div class="desc" style="text-align:justify;padding:5px;padding-top:10px;">
                      <p style="font-weight:bold; font-size:18px;color:black;"><b>ABOUT US</b></p>
                      <p style="font-size:15px;"><i>We are an Ontario Corporation registered with the Ministry of Commerce and Commercial Relations on 19 March 1997. As embedded in our Charter, we carry out our activities without the purpose of gain for our Members, and any profits or other accretions to the Corporation are used in promoting our objects.</i></p>

<p style="font-weight:bold; font-size:18px;color:black;"><b>OUR VISION</b></p>
<p style="font-size:15px;"><i>To assist Bangladeshi professionals in Accounting and Finance to sustainably integrate into Canadian Society.</i></p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-5" >
            <div class="#">
              <div class="row">
                <div class="col-md-12">
                  <div class="teacher-info">
                    <div class="desc" style="text-align:justify;padding:5px;padding-top:10px;">
                      <p style="font-weight:bold; font-size:18px;color:black;"><b>OUR MISSION</b></p>
                      <p style="font-size:15px;"><i>To give counsel to newcomers in Ontario from Bangladesh with Accounting and Finance background on what needs to be done to register with the government authorities, to get credentials assessed by the competent authorities and to connect with the employment agencies, various government agencies and social organizations for networking and settlement.

To advice on the facilities available for Career Development and socialization to understand and acquaint with the new culture and systems.

To arrange Seminars to keep the Diasporas updated on new policy and procedures in their professional fields.

To aim to get ABPAFC recognized as a premier brand of finance, accounting and business professionals in Canada</i></p>

                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-md-1">
          </div>

        </div>
      </section>    


      
      <!-- Site Footer-->
      <!-- Site Footer-->
      <footer class="site-footer" style="background-color:#18a577;padding-top:35px !important; ">
        <div class="container">
          <div class="row">
            <div class="col-md-5">
              <!-- Contact Info-->
              <section class="widget widget-light-skin">
                <h3 class="widget-title" style="color:black;font-weight:bold; font-size:13px;">2899 Danforth Ave, Toronto, Ontario, M4C 1M3, Canada</h3>

              </section>
            </div>
            <div class="col-md-3">
              <!-- Mobile App Buttons-->
              <section class="widget widget-light-skin">
                <h3 class="widget-title" style="color:black;font-weight:bold; font-size:13px;">Phone: 647-267-8699</h3>
              </section>
            </div>
            <div class="col-md-3">
              <!-- About Us-->
              <section class="widget widget-links widget-light-skin">
                <h3 class="widget-title" style="color:black;font-weight:bold; font-size:13px;">Email: abpafc@gmail.com</h3>
                
              </section>
            </div>

            <div class="col-md-1">
              <!-- About Us-->
              <section class="widget widget-links widget-light-skin">
                <h3 class="widget-title" style="color:black;font-weight:bold; font-size:13px;"><a href="#" style="color:red;">Membership</a></h3>
                
              </section>
            </div>

          </div>

        </div>
      </footer>
    </div>
    <!-- Back To Top Button--><a class="scroll-to-top-btn" href="#"><i class="icon-arrow-up"></i></a>
    <!-- Backdrop-->
    <div class="site-backdrop"></div>
    <!-- JavaScript (jQuery) libraries, plugins and custom scripts-->
    <script src="<?php echo base_url(); ?>website_assets/js/vendor.min.js"></script>
    <script src="<?php echo base_url(); ?>website_assets/js/scripts.min.js"></script>
    <!-- Customizer scripts-->
    <script src="<?php echo base_url(); ?>website_assets/customizer/customizer.min.js"></script>
  </body>

<!-- Mirrored from themes.rokaux.com/unishop/v3.1/template-1/ by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 11 Feb 2019 17:25:51 GMT -->
</html>

<script>
$(document).ready(function(){
 $.ajax({
        type: 'POST',
        dataType: 'json',
        url:"<?php echo base_url(); ?>index.php/shopping_cart/get_counter",
        
        success: function (data) {
            $('#cart_counter_number').html(data);
            $('#second_cart_counter_number').html(data);
 
        }
    });
 $('.add_cart').click(function(){
  var product_id = $(this).data("productid");
  var product_name = $(this).data("productname");
  var product_price = $(this).data("price");
  var vendor_id = $(this).data("vendorid");

  var quantity = $('#' + product_id).val();

  // alert(product_id);
  // alert(product_name);
  // alert(product_price);
  // alert(quantity);
  if(quantity != '' && quantity > 0)
  {
   $.ajax({
    url:"<?php echo base_url(); ?>index.php/shopping_cart/add",
    method:"POST",
    data:{product_id:product_id, product_name:product_name, product_price:product_price, quantity:quantity, vendor_id:vendor_id},
    success:function(data)
    {
     $('#cart_details').html(data);
     $('#' + product_id).val('');

     $.ajax({
        type: 'POST',
        dataType: 'json',
        url:"<?php echo base_url(); ?>index.php/shopping_cart/get_counter",
        
        success: function (data) {
            $('#cart_counter_number').html(data);
            $('#second_cart_counter_number').html(data);
        }
    });
    }
   });
  }
  else
  {
   alert("Please Enter quantity");
  }
 });

 $('#cart_details').load("<?php echo base_url(); ?>index.php/shopping_cart/load");



 $(document).on('click', '.remove_inventory', function(){
  var row_id = $(this).attr("id");
  $.ajax({
    url:"<?php echo base_url(); ?>index.php/shopping_cart/remove",
    method:"POST",
    data:{row_id:row_id},
    success:function(data)
    {
     $('#cart_details').html(data);

     $.ajax({
        type: 'POST',
        dataType: 'json',
        url:"<?php echo base_url(); ?>index.php/shopping_cart/get_counter",
        
        success: function (data) {
            $('#cart_counter_number').html(data);
            $('#second_cart_counter_number').html(data);
        }
    });
    }
   });
 });

 $(document).on('click', '#clear_cart', function(){
  $.ajax({
    url:"<?php echo base_url(); ?>index.php/shopping_cart/clear",
    success:function(data)
    {
     $('#cart_details').html(data);
     $.ajax({
        type: 'POST',
        dataType: 'json',
        url:"<?php echo base_url(); ?>index.php/shopping_cart/get_counter",
        
        success: function (data) {
            $('#cart_counter_number').html(data);
            $('#second_cart_counter_number').html(data);
        }
    });
    }
   });
 });

 $(document).on('click', '.checkout_btn', function(){
    var url="<?php echo base_url(); ?>index.php/website/checkout/";
  $.ajax({
    url:url,
    success:function(data)
    {
         window.location = url;   
        //window.location.reload(url);
    }
   });


 });

});
</script>