
<style>

.view_details{
    padding: 10px 20px;
    box-shadow: 0px 1px 1px 0px #979797;
    background-color: white;
    color: black;
    transition: all 1s;
    transform: scale(1);
    border-radius: 4px;
}

.view_details a
{
    color:green;
}
.text-dark a{

    color:green;
}
.all_shop a
{
     color:green;
}
.aplus_shop
{
    background-color: #61d800;
}
.a_shop
{
    background-color: #8470ff;
}
.b_shop
{
    background-color: #FFFF00;
}
.c_shop
{
    background-color: #FF8000;
}
</style>
<script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
<div class="content-page">
                <!-- Start content -->
                <div class="content">
                    <div class="container-fluid">

                        <!-- Page-Title -->
                        <div class="row">
                            <div class="col-sm-12">
                                <h5 class="pull-left all_shop" style="color:green;">Cheapers Status : <a href="#"></a></h5>
                                <ol class="breadcrumb pull-right">
                                   <!--  <li><a href="#">BFSA Evaluation</a></li>
                                    <li class="active">Dashboard</li> -->
                                </ol>
                            </div>
                        </div>

                        <!-- Start Widget -->
                        <!--Widget-4 -->
                        <div class="row">
                            
                            <div class="col-md-6 col-xl-3">
                                <div class="mini-stat clearfix bx-shadow bg-white">
                                    
                                    <span class="mini-stat-icon bg-success"><i class="ion-android-contacts"></i></span>
                                    <div class="mini-stat-info text-right text-dark">
                                        <span class="counter text-dark"><a href="<?php echo base_url();?>index.php/order/pending_order/"><?php echo $pending_order;?></a></span>
                                        Total Pending Order
                                    </div>
                                    <div class="tiles-progress">
                                        <div class="m-t-20">
                                            <h5 class=""> <span class="pull-right view_details"><a href="#">View Details</a></span></h5>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3">
                                <div class="mini-stat clearfix bx-shadow bg-white">
                                    <span class="mini-stat-icon bg-success"><i class="ion-android-contacts"></i></span>
                                    <div class="mini-stat-info text-right text-dark">
                                        <span class="counter text-dark"><a href="#"><?php echo $mills;?></a></span>
                                        Total Customer
                                    </div>
                                    <div class="tiles-progress">
                                        <div class="m-t-20">
                                            <h5 class=""> <span class="pull-right view_details"><a href="#">View Details</a></span></h5>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3">
                                <div class="mini-stat clearfix bx-shadow bg-white">
                                    <span class="mini-stat-icon bg-success"><i class="ion-android-contacts"></i></span>
                                    <div class="mini-stat-info text-right text-dark">
                                        <span class="counter text-dark"><a href=""><?php echo $buyer;?></a></span>
                                        Total Brand
                                    </div>
                                    <div class="tiles-progress">
                                        <div class="m-t-20">
                                            <h5 class=""> <span class="pull-right view_details"><a href="#">View Details</a></span></h5>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3">
                                <div class="mini-stat clearfix bx-shadow bg-white">
                                    <span class="mini-stat-icon bg-purple"><i class="ion-ios7-cart"></i></span>
                                    <div class="mini-stat-info text-right text-dark">
                                        <span class="counter text-dark"><a href="#"><a href=""><?php echo $all_gray;?></a></span>
                                        Total Stock
                                    </div>
                                    <div class="tiles-progress">
                                        <div class="m-t-20">
                                            <h5 class=""> <span class="pull-right view_details"><a href="#">View Details</a></span></h5>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- End row-->

                         <div class="row">
                            
                            <div class="col-md-6 col-xl-3">
                                <div class="mini-stat clearfix bx-shadow bg-white">
                                    
                                    <span class="mini-stat-icon bg-purple"><i class="ion-ios7-cart"></i></span>
                                    <div class="mini-stat-info text-right text-dark">
                                        <span class="counter text-dark"><a href=""><?php echo $mill_stock;?></a></span>
                                        Total Vendor
                                    </div>
                                    <div class="tiles-progress">
                                        <div class="m-t-20">
                                            <h5 class=""> <span class="pull-right view_details"><a href="#">View Details</a></span></h5>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3">
                                <div class="mini-stat clearfix bx-shadow bg-white">
                                    <span class="mini-stat-icon bg-purple"><i class="ion-ios7-cart"></i></span>
                                    <div class="mini-stat-info text-right text-dark">
                                        <span class="counter text-dark"><a href=""><?php echo $printed_stock;?></a></span>
                                        Total Product
                                    </div>
                                    <div class="tiles-progress">
                                        <div class="m-t-20">
                                            <h5 class=""> <span class="pull-right view_details"><a href="#">View Details</a></span></h5>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3">
                                <div class="mini-stat clearfix bx-shadow bg-white">
                                     <span class="mini-stat-icon bg-purple"><i class="ion-ios7-cart"></i></span>
                                    <div class="mini-stat-info text-right text-dark">
                                        <span class="counter text-dark"><?php echo $saleable_stock;?></span>
                                        Total Category
                                    </div>
                                    <div class="tiles-progress">
                                        <div class="m-t-20">
                                            <h5 class=""> <span class="pull-right view_details"><a href="#">View Details</a></span></h5>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-3">
                                <div class="mini-stat clearfix bx-shadow bg-white">
                                     <span class="mini-stat-icon bg-info"><i class="ion-social-usd"></i></span>
                                    <div class="mini-stat-info text-right text-dark">
                                        <span class="counter text-dark"><?php echo $total_sales;?></span>
                                        Total Subcatgory
                                    </div>
                                    <div class="tiles-progress">
                                        <div class="m-t-20">
                                            <h5 class=""> <span class="pull-right view_details"><a href="#">View Details</a></span></h5>
                                           
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div> <!-- End row-->

                        <div class="card-body portlet"> 
                            <div class="table-rep-plugin">
                                <div class="table-responsive" data-pattern="priority-columns">
                                    <table id="tech-companies-1" class="table table-small-font table-bordered table-striped">
                                        <div id="piechart" style="padding-bottom:130px;text-align:center">Here Will Be Total Profit Summary</div>
                                    </table>
                                </div> 
                            </div>
                        </div> 
                           

                        <!-- End row -->

                       

                    </div> <!-- container -->
                               
                </div> <!-- content -->

                 <footer class="footer text-right">
                    2018-2019©. Design & Developed By <a target="_blank" href="http://rassolutionbd.com/">RassolutionBD</a>
                </footer>

            </div>

            <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

            <script type="text/javascript">
            
            // Load google charts
            google.charts.load('current', {'packages':['corechart']});
            google.charts.setOnLoadCallback(drawChart);

            // Draw the chart and set the chart values
            function drawChart() {
              var data = google.visualization.arrayToDataTable([
              ['Task', 'Shop List'],

              <?php 

              foreach($counting_shop as $index=>$count_shop)
              {
                echo "['".$index."',".$count_shop."],";
              }
              ?>
            ]);

              // Optional; add a title and set the width and height of the chart
              var options = {
                'title':'BFSA Evaluation',
                'width':550,
                'height':350,
                'colors': ['#61d800', '#8470ff', '#FFFF00', '#FF8000']
            };

              // Display the chart inside the <div> element with id="piechart"
              var chart = new google.visualization.PieChart(document.getElementById('piechart'));
              chart.draw(data, options);
            }
            </script>

