<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <title>Cheapers Ecommerce Login</title>
 <style type="text/css">
 body{
  background-image: url('<?php echo base_url();?>images/LSI-background-ecommerce-solutions.jpg');
  background-size: cover;
 }
 .aa{
  margin-top: 150px !important;
  width: 255px;
  height: 260px;
  background-color: rgba(0,0,0,0.4);
  margin: 0 auto;
  margin-top: 40px;
  padding-top: 10px;
  padding-left: 50px;
  -webkit-border-color: 15px;
  -moz-border-color: 15px;
  -ms-border-color: 15px;
  -o-border-color: 15px;
  border-color: 15px;
  color:white;
  font-weight: bolder;
  -webkit-box-shadow: 1px 4px 6px graytext;
  box-shadow: 1px 4px 6px graytext;
  font-size: 18px;
 }
 .aa input[type="text"]{
  width: 200px;
  height: 35px;
  border:0px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  -ms-border-radius: 5px;
  -o-border-radius: 5px;
  border-radius: 5px;
  padding-left: 5px;
 }
 .aa input[type="password"]{
  width: 200px;
  height: 35px;
  border:0px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  -ms-border-radius: 5px;
  -o-border-radius: 5px;
  border-radius: 5px;
  padding-left: 5px;
 }
 .aa input[type="submit"]{
  width: 200px;
  height: 35px;
  border:0px;
  -webkit-border-radius: 5px;
  -moz-border-radius: 5px;
  -ms-border-radius: 5px;
  -o-border-radius: 5px;
  border-radius: 5px;
  background-color: skyblue;
  font-weight: bolder;
 }
 </style>
</head>
<body>
 <div class="aa">
 <h2 class="do_center" style="padding-left:50px;">Cheapers</h2>
  <form class="form-horizontal m-t-20" action="<?php echo base_url();?>index.php/login/admin_login_check/" method="post">
   <input type="text" name="user_name" placeholder="Enter Your Username"><br><br>
   <input type="password" name="password" placeholder="Enter Your password"><br><br>
   <input type="submit" value="Login"><br>
  </form><!-- close form -->
 </div><!-- close aa -->
</body>
</html>