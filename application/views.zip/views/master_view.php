<!DOCTYPE html>
<html lang="en">
    
<!-- Mirrored from coderthemes.com/moltran/green/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 10 Nov 2018 15:28:12 GMT -->
<head>
        <meta charset="utf-8" />
        <title>Cheapers Ecommerce</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
        <meta content="Coderthemes" name="author" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />

        <link rel="shortcut icon" href="<?php echo base_url(); ?>assets/images/favicon.ico">

        <link href="<?php echo base_url(); ?>../plugins/sweetalert2/sweetalert2.css" rel="stylesheet" type="text/css">

        <!-- Custom Files -->
        <link href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css">
        <link href="<?php echo base_url(); ?>assets/css/icons.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/style.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/select2.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url(); ?>assets/css/select2-bootstrap.css" rel="stylesheet" type="text/css" />
            
        <script src="<?php echo base_url(); ?>assets/js/select2.min.js"></script>

            <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/modernizr.min.js"></script>
            <script src="<?php echo base_url(); ?>assets/js/jquery-ui.min.js"></script>

            



    </head>


    <body class="fixed-left">
        
        <!-- Begin page -->
        <div id="wrapper">

            <!-- Top Bar Start -->
            <div class="topbar">
                <!-- LOGO -->
                <div class="topbar-left">
                    <div class="text-center" style="text-shadow: 2px 2px 4px #000000 !important;">
                        <a href="<?php echo base_url();?>" class="logo"><img src="<?php echo base_url(); ?>assets/images/logo.png" alt="" class="thumb-md rounded-circle"> <span>Cheapers</span></a>
                    </div>
                </div>
                <!-- Button mobile view to collapse sidebar menu -->
                
                <nav class="navbar navbar-default">
                    <div class="container-fluid">
                        <ul class="list-inline menu-left mb-0">
                            <li class="float-left">
                                <a href="#" class="button-menu-mobile open-left">
                                    <i class="fa fa-bars"></i>
                                </a>
                            </li>
                            <li class="hide-phone float-left">
                                <!-- <form role="search" class="navbar-form">
                                    <input type="text" placeholder="Type here for search..." class="form-control search-bar">
                                    <a href="#" class="btn btn-search"><i class="fa fa-search"></i></a>
                                </form> -->
                            </li>
                        </ul>
    
                        <ul class="nav navbar-right float-right list-inline">
                           
                            <li class="d-none d-sm-block">
                                <a href="#" id="btn-fullscreen" class="waves-effect waves-light"><i class="md md-crop-free"></i></a>
                            </li>
                            
                            <li class="dropdown open">
                                 <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <b><?php echo $this->session->userdata('admin_logged_in');?></b>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo base_url();?>index.php/profile/view_profile" class="dropdown-item"><i class="md md-face-unlock mr-2"></i> Profile</a></li>
                                    <li><a href="javascript:void(0)" class="dropdown-item"><i class="md md-settings mr-2"></i> Settings (In Progress)</a></li>
                                   
                                    <li><a href="<?php echo base_url();?>index.php/login/admin_logout/" class="dropdown-item"><i class="md md-settings-power mr-2"></i> Logout</a></li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <!-- Top Bar End -->

            <!-- ========== Left Sidebar Start ========== -->

            <div class="left side-menu" style="box-shadow: 0 5px 8px 0 gray;">
                <div class="sidebar-inner slimscrollleft">
                    <div class="user-details">
                        <!-- <div class="pull-left">
                            <img src="<?php echo base_url(); ?>assets/images/users/demo.png" alt="" class="thumb-md rounded-circle">
                        </div> -->
                        <div class="pull-left">
                            <div class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                        <b><?php echo $this->session->userdata('admin_logged_in');?></b>
                                </a>
                                <ul class="dropdown-menu">
                                    <li><a href="<?php echo base_url();?>index.php/profile/view_profile" class="dropdown-item"><i class="md md-face-unlock mr-2"></i> Profile <div class="ripple-wrapper"></div></a></li>
                                    <li><a href="javascript:void(0)" class="dropdown-item"><i class="md md-settings mr-2"></i> Settings (In Progress)</a></li>
                                    
                                     <li><a href="<?php echo base_url();?>index.php/login/admin_logout"><i class="md md-settings-power"></i> Logout</a></li>
                                </ul>
                            </div>
                            
                            <p class="text-muted m-0">Administrator</p>
                        </div>
                    </div>
                    <!--- Divider -->
                    <div id="sidebar-menu">
                        <ul>
                            <li>
                                <a href="<?php echo base_url();?>" class="waves-effect"><i class="md md-home"></i><span> Dashboard </span></a>
                            </li>
                            <li>
                                <a target="_blank" href="<?php echo base_url();?>index.php/website/" class="waves-effect"><i class="md md-home"></i><span> View Website </span></a>
                            </li>

                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Setup </span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/user/manage_user/">Manage User</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/supplier/manage_supplier/">Manage Supplier</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/buyer/manage_buyer/">Manage Customer</a></li>  
                                    <li><a href="<?php echo base_url();?>index.php/color/manage_color/">Manage Color</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/costing_item/manage_costing_item/">Manage Costing Item</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/uom/manage_uom/">Manage UOM</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/vendor_type/manage_vendor_type/">Manage Vendor Type</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/customer_type/manage_customer_type/">Manage Customer Type</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/category/manage_category/">Manage Category</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/subcategory/manage_subcategory/">Manage Sub Category</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/brand/manage_brand/">Manage Brand</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/profession/manage_profession/">Manage Profession</a></li>

                                </ul>
                            </li>
                            
                           
                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Manage Vendor</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/vendor/manage_vendor/">Manage Vendor</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Manage Customer</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/customer/manage_customer/">Manage Customer</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Manage Product</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/product/manage_product/">Manage Product</a></li>
                                </ul>
                            </li>
                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Manage Inventory</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/inventory/manage_inventory/">Manage Inventory</a></li>
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Manage Order</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/order/pending_order/">Pending Order</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/order/delivered_order/">Delivered Order</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/order/cancelled_order/">Cancelled Order</a></li>
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Service Provider</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/service_provider/manage_service_provider/">Manage Provider</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/service_provider/pending_service_provider/">Pending List</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/service_provider/approved_service_provider/">Approved List</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/service_provider/cancelled_service_provider/">Cancelled List</a></li>
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Service Receiver</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/service_receiver/pending_service/">Pending Service</a></li>
                                    <li><a href="<?php echo base_url();?>index.php/service_receiver/delivered_service/">Delivered Service</a></li>
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Ambulance Service</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/ambulance_service/pending_ambulance_service/">Pending Ambulance Service</a></li>

<!--                                     <li><a href="<?php echo base_url();?>index.php/ambulance_service/delivered_ambulance_service/">Delivered Ambulance Service</a></li>
 -->                                
                                </ul>
                            </li>

                            <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Blood Donor</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/blood_donor/manage_blood_donor/">Manage Blood Donor</a></li>
                                     <li><a href="<?php echo base_url();?>index.php/blood_stock/manage_blood_stock/">Add Blood</a></li>
                                </ul>
                            </li>

                             <li class="has_sub">
                                <a href="#" class="waves-effect"><i class="md md-view-list"></i><span>Sales</span><span class="pull-right"><i class="md md-add"></i></span></a>
                                <ul class="list-unstyled">
                                    <li><a href="<?php echo base_url();?>index.php/sales/manage_sales/">Sales</a></li>
                                </ul>
                            </li>

                            

                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <!-- Left Sidebar End --> 

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->                      
            
            <!-- ============================================================== -->
            <!-- End Right content here -->
            <!-- ============================================================== -->

            <?php 
                echo $main_content;
            ?>
            <!-- Right Sidebar -->
            <div class="side-bar right-bar nicescroll">
                <h4 class="text-center">Chat</h4>
                <div class="contact-list nicescroll">
                    <ul class="list-group contacts-list">
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-1.jpg" alt="">
                                </div>
                                <span class="name">Chadengle</span>
                                <i class="fa fa-circle online"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-2.jpg" alt="">
                                </div>
                                <span class="name">Tomaslau</span>
                                <i class="fa fa-circle online"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-3.jpg" alt="">
                                </div>
                                <span class="name">Stillnotdavid</span>
                                <i class="fa fa-circle online"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-4.jpg" alt="">
                                </div>
                                <span class="name">Kurafire</span>
                                <i class="fa fa-circle online"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-5.jpg" alt="">
                                </div>
                                <span class="name">Shahedk</span>
                                <i class="fa fa-circle away"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-6.jpg" alt="">
                                </div>
                                <span class="name">Adhamdannaway</span>
                                <i class="fa fa-circle away"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-7.jpg" alt="">
                                </div>
                                <span class="name">Ok</span>
                                <i class="fa fa-circle away"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-8.jpg" alt="">
                                </div>
                                <span class="name">Arashasghari</span>
                                <i class="fa fa-circle offline"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-9.jpg" alt="">
                                </div>
                                <span class="name">Joshaustin</span>
                                <i class="fa fa-circle offline"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                        <li class="list-group-item">
                            <a href="#">
                                <div class="avatar">
                                    <img src="<?php echo base_url(); ?>assets/images/users/avatar-10.jpg" alt="">
                                </div>
                                <span class="name">Sortino</span>
                                <i class="fa fa-circle offline"></i>
                            </a>
                            <span class="clearfix"></span>
                        </li>
                    </ul>  
                </div>
            </div>
            <!-- /Right-bar -->

        </div>
        <!-- END wrapper -->

        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  
         
        <script src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
        -->
          <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>

        <script src="<?php echo base_url(); ?>assets/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/detect.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/fastclick.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.slimscroll.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.blockUI.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/waves.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/wow.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.nicescroll.js"></script>
        <script src="<?php echo base_url(); ?>assets/js/jquery.scrollTo.min.js"></script>
        <!-- jQuery -->
        <script src="<?php echo base_url(); ?>assets/plugins/moment.min.js"></script>
        <!-- Counter js  -->
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.waypoints.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.counterup.min.js"></script>
        
        <!-- sweet alerts -->
        <script src="<?php echo base_url(); ?>assets/plugins/sweetalert2.js"></script>
        
        <!-- flot Chart -->
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.flot.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.flot.time.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.flot.tooltip.min.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.flot.resize.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.flot.pie.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.flot.selection.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.flot.stack.js"></script>
        <script src="<?php echo base_url(); ?>assets/plugins/jquery.flot.crosshair.js"></script>

        <!-- Todoapp -->
        <script src="<?php echo base_url(); ?>assets/pages/jquery.todo.js"></script>
        
        <!-- jQuery  -->
        <script src="<?php echo base_url(); ?>assets/pages/jquery.chat.js"></script>
        
        <!-- Dashboard js  -->
        <script src="<?php echo base_url(); ?>assets/pages/jquery.dashboard.js"></script>

        <!-- App js  -->
        <script src="<?php echo base_url(); ?>assets/js/jquery.app.js"></script>
        
        <script>
            /* ==============================================
            Counter Up
            =============================================== */
            jQuery(document).ready(function($) {
                $('.counter').counterUp({
                    delay: 100,
                    time: 1200
                });
            });
            
        </script>

        

    </body>

<!-- Mirrored from coderthemes.com/moltran/green/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 10 Nov 2018 15:28:37 GMT -->
</html>